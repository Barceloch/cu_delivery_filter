{
    'name': 'Gestión de Contratos GTI',
    'version': '18.0.1.0.1',
    'category': 'Legal/Contracts',
    'summary': 'Registro y control de contratos para MIPYMES cubanas',
    'description': """
        Módulo de Gestión de Contratos para GTI SRL
        ===========================================
        * Registro de contratos con clasificación legal cubana
        * Control de vigencia y vencimientos
        * Múltiples partes (hasta 4)
        * Métodos de pago específicos (Efectivo, Transferencia, Pagaré, etc.)
        * Valor del contrato en CUP
        * Suplementos de contrato
        * Alertas de vencimiento
        * Exportación a CSV/Excel
    """,
    'author': 'GTI SRL - Consultoría Odoo Cuba',
    'website': 'https://gti-srl.cu',
    'license': 'LGPL-3',
    'depends': [
        'base',
        'mail',
        'contacts',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/contract_sequence.xml',
        'views/gti_contratos_views.xml',
        'views/menu.xml',
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime, timedelta
import json
import csv
import io

class GtiContratos(models.Model):
    _name = 'gti.contratos'
    _description = 'Registro de Contratos GTI'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date_signed desc, name desc'

    # ========== IDENTIFICACIÓN DEL CONTRATO ===========
    name = fields.Char(string='Número de Contrato', required=True, copy=False, 
                       default='Nuevo', tracking=True)
    contract_type = fields.Selection([
        ('contract', 'Contrato'),
        ('supplement', 'Suplemento'),
        ('supplemented', 'Contrato Suplementado'),
    ], string='Tipo de Registro', required=True, default='contract', tracking=True)
    
    parent_contract_id = fields.Many2one('gti.contratos', string='Contrato Principal',
                                         domain=[('contract_type', '=', 'contract')],
                                         help='Contrato base para suplementos')
    
    date_signed = fields.Date(string='Fecha de Suscripción', required=True, 
                              default=fields.Date.context_today, tracking=True)
    
    # ========== CLASIFICACIÓN ===========
    contract_category = fields.Selection([
        ('sale', 'Compraventa'),
        ('lease', 'Arrendamiento (Alquiler)'),
        ('service', 'Prestación de Servicios'),
        ('supply', 'Suministro'),
        ('construction', 'Obras / Construcción'),
        ('consulting', 'Consultoría'),
        ('distribution', 'Distribución'),
        ('franchise', 'Franquicia'),
        ('license', 'Licencia de Uso'),
        ('nda', 'Confidencialidad (NDA)'),
        ('joint_venture', 'Joint Venture'),
        ('agency', 'Agencia'),
        ('mandate', 'Mandato'),
        ('transport', 'Transporte'),
        ('insurance', 'Seguros'),
        ('credit', 'Crédito / Financiamiento'),
        ('labor', 'Trabajo / Laboral'),
        ('service_lease', 'Arrendamiento de Servicios'),
        ('commodate', 'Comodato'),
        ('deposit', 'Depósito'),
        ('guarantee', 'Fianza / Garantía'),
        ('other', 'Otro'),
    ], string='Tipo de Contrato', required=True, tracking=True)
    
    legal_nature = fields.Selection([
        ('supplier', 'Proveedor'),
        ('customer', 'Cliente'),
    ], string='Naturaleza Jurídica', required=True, tracking=True)
    
    # ========== MÉTODO DE PAGO ===========
    payment_method = fields.Selection([
        ('cash', 'Pago en Efectivo'),
        ('transfer', 'Transferencia Bancaria'),
        ('check', 'Cheque'),
        ('promissory', 'Pagaré'),
        ('bill_exchange', 'Letra de Cambio'),
        ('other', 'Otro'),
    ], string='Método de Pago', required=True, tracking=True)
    
    # ========== VIGENCIA Y VALOR ===========
    duration_years = fields.Integer(string='Vigencia (años)', required=True, default=1)
    date_start = fields.Date(string='Fecha de Inicio', compute='_compute_dates', store=True)
    date_end = fields.Date(string='Fecha de Fin', compute='_compute_dates', store=True, tracking=True)
    
    contract_value = fields.Float(string='Valor (CUP)', required=True, tracking=True)
    invoices_total = fields.Float(string='Suma de Facturas', compute='_compute_invoices', store=True)
    
    currency_id = fields.Many2one('res.currency', string='Moneda', 
                                  default=lambda self: self.env.ref('base.CUP').id)
    
    # ========== PARTES ===========
    partner_ids = fields.Many2many('res.partner', string='Partes en el Acuerdo', 
                                   help='Máximo 4 partes en el acuerdo')
    
    # ========== ESTADO ===========
    state = fields.Selection([
        ('draft', 'Borrador'),
        ('active', 'Vigente'),
        ('expiring', 'Próximo a Vencer'),
        ('expired', 'Vencido'),
        ('cancelled', 'Cancelado'),
    ], string='Estado', default='draft', tracking=True)
    
    # ========== OBSERVACIONES ===========
    notes = fields.Text(string='Observaciones', help='Notas adicionales')
    
    # ========== CAMPOS CALCULADOS ===========
    days_until_expiry = fields.Integer(string='Días para Vencer', compute='_compute_expiry')
    is_expiring_soon = fields.Boolean(string='Próximo a Vencer', compute='_compute_expiry')
    
    # ========== RELACIONES ===========
    invoice_ids = fields.Many2many('account.move', string='Facturas Vinculadas',
                                   relation='gti_contratos_invoice_rel',
                                   column1='contratos_id', column2='invoice_id')
    
    supplement_ids = fields.One2many('gti.contratos', 'parent_contract_id', 
                                     string='Suplementos',
                                     domain=[('contract_type', '=', 'supplement')])
    
    supplements_count = fields.Integer(string='Cantidad de Suplementos', 
                                       compute='_compute_supplements')

    # ========== MÉTODOS ===========
    
    @api.depends('date_signed', 'duration_years')
    def _compute_dates(self):
        for record in self:
            if record.date_signed and record.duration_years:
                record.date_start = record.date_signed
                record.date_end = record.date_signed + timedelta(days=record.duration_years * 365)
            else:
                record.date_start = False
                record.date_end = False
    
    @api.depends('date_end')
    def _compute_expiry(self):
        today = fields.Date.today()
        for record in self:
            if record.date_end:
                delta = (record.date_end - today).days
                record.days_until_expiry = delta
                record.is_expiring_soon = 0 < delta <= 30
            else:
                record.days_until_expiry = False
                record.is_expiring_soon = False
    
    @api.depends('invoice_ids', 'invoice_ids.amount_total')
    def _compute_invoices(self):
        for record in self:
            record.invoices_total = sum(record.invoice_ids.mapped('amount_total'))
    
    @api.depends('supplement_ids')
    def _compute_supplements(self):
        for record in self:
            record.supplements_count = len(record.supplement_ids)
    
    @api.model
    def create(self, vals):
        # Asignar número consecutivo si es contrato nuevo
        if vals.get('contract_type') == 'contract' and vals.get('name', 'Nuevo') == 'Nuevo':
            vals['name'] = self.env['ir.sequence'].next_by_code('gti.contratos.sequence') or 'Nuevo'
        return super().create(vals)
    
    # ✅ CORREGIDO: Eliminar llamada recursiva a _update_state
    def write(self, vals):
        # Solo actualizar estado si NO se está modificando el estado directamente
        if 'state' not in vals:
            # Usar super para evitar recursión
            result = super().write(vals)
            # Actualizar estado solo para registros que no están siendo modificados ahora
            self._update_state_safe()
            return result
        return super().write(vals)
    
    def _update_state_safe(self):
        """Actualizar estado sin causar recursión"""
        today = fields.Date.today()
        for record in self:
            if record.state == 'cancelled':
                continue
            
            if record.date_end:
                new_state = None
                if record.date_end < today:
                    new_state = 'expired'
                elif record.is_expiring_soon:
                    new_state = 'expiring'
                elif record.date_start and record.date_start <= today and record.state == 'draft':
                    new_state = 'active'
                
                # Solo actualizar si el estado cambió y evitar recursión
                if new_state and new_state != record.state:
                    # Usar write directo en la base de datos para evitar trigger
                    self.env.cr.execute(
                        "UPDATE gti_contratos SET state = %s WHERE id = %s",
                        (new_state, record.id)
                    )
                    record.invalidate_recordset(['state'])
    
    def _update_state(self):
        """Método público para actualizar estados manualmente (ej: desde acción programada)"""
        self._update_state_safe()
    
    # ========== ACCIONES ===========
    
    def action_activate(self):
        """Activar contrato - cambia estado a 'active' directamente"""
        for record in self:
            # Actualizar directamente sin pasar por write() para evitar recursión
            self.env.cr.execute(
                "UPDATE gti_contratos SET state = %s WHERE id = %s",
                ('active', record.id)
            )
            record.invalidate_recordset(['state'])
        return True
    
    def action_cancel(self):
        self.write({'state': 'cancelled'})
        return True
    
    def action_draft(self):
        self.write({'state': 'draft'})
        return True
    
    def action_create_supplement(self):
        """Crear un suplemento del contrato seleccionado"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Crear Suplemento'),
            'res_model': 'gti.contratos',
            'view_mode': 'list,form',
            'target': 'current',
            'context': {
                'default_contract_type': 'supplement',
                'default_parent_contract_id': self.id,
                'default_legal_nature': self.legal_nature,
                'default_partner_ids': [(6, 0, self.partner_ids.ids)],
            }
        }
    
    def action_view_supplements(self):
        """Ver suplementos del contrato"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Suplementos'),
            'res_model': 'gti.contratos',
            'view_mode': 'list,form',
            'domain': [('parent_contract_id', '=', self.id)],
            'context': {'default_parent_contract_id': self.id}
        }
    
    def action_view_invoices(self):
        """Ver facturas vinculadas"""
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': _('Facturas Vinculadas'),
            'res_model': 'account.move',
            'view_mode': 'list,form',
            'domain': [('id', 'in', self.invoice_ids.ids)],
        }
    
    # ========== EXPORTACIÓN ===========
    
    def export_to_csv(self):
        """Exportar contratos a CSV"""
        self.ensure_one()
        output = io.StringIO()
        writer = csv.writer(output, delimiter=';')
        
        # Headers
        writer.writerow([
            'Número', 'Tipo', 'Fecha Suscripción', 'Categoría', 
            'Naturaleza', 'Método Pago', 'Valor (CUP)', 'Vigencia (años)',
            'Fecha Inicio', 'Fecha Fin', 'Estado', 'Partes', 'Observaciones'
        ])
        
        # Data
        writer.writerow([
            self.name,
            self.contract_type,
            self.date_signed,
            self.contract_category,
            self.legal_nature,
            self.payment_method,
            self.contract_value,
            self.duration_years,
            self.date_start,
            self.date_end,
            self.state,
            ', '.join(self.partner_ids.mapped('name')),
            self.notes or ''
        ])
        
        output.seek(0)
        return {
            'type': 'ir.actions.act_url',
            'url': f'text/csv;charset=utf-8,{output.getvalue()}',
            'target': 'new',
        }
    
    # ========== VALIDACIONES ===========
    
    @api.constrains('partner_ids')
    def _check_partner_count(self):
        for record in self:
            if len(record.partner_ids) > 4:
                raise ValidationError(_('No se pueden agregar más de 4 partes en el acuerdo'))
    
    @api.constrains('duration_years')
    def _check_duration(self):
        for record in self:
            if record.duration_years <= 0:
                raise ValidationError(_('La vigencia debe ser mayor a 0 años'))
    
    @api.constrains('contract_value')
    def _check_value(self):
        for record in self:
            if record.contract_value < 0:
                raise ValidationError(_('El valor del contrato no puede ser negativo'))